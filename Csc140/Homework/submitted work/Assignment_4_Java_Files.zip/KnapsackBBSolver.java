import javax.lang.model.util.ElementScanner14;
import java.util.Arrays;

// Branch-and-Bound solver
public class KnapsackBBSolver extends KnapsackBFSolver
{
protected UPPER_BOUND ub;
private int sum;
protected KnapsackInstance inst;
protected KnapsackSolution crntSoln;
protected KnapsackSolution bestSoln;

public void FindSolns(int itemNum, int untakenVal, int load)
{
	int itemCnt = inst.GetItemCnt();

	if (load > inst.GetCapacity())
	{
		return;
	}

	if (itemNum == itemCnt + 1)
	{
		CheckCrntSoln();
		return;
	}	
	if(ub.getValue() == 0){
		if(ub1(untakenVal))
			return;
	}
	else if(ub.getValue() == 1){
		if(ub2(itemNum))
			return;
	}
	else if(ub.getValue() == 2){
		if(ub3(itemNum))
			return;
	}
	crntSoln.TakeItem(itemNum);
	untakenVal -= inst.GetItemValue(itemNum);
	load += inst.GetItemWeight(itemNum);
	FindSolns(itemNum + 1,untakenVal, load);
	crntSoln.DontTakeItem(itemNum);
	untakenVal += inst.GetItemValue(itemNum);
	load -= inst.GetItemWeight(itemNum);
	FindSolns(itemNum + 1, untakenVal, load);
}
public void CheckCrntSoln()
{
	int crntVal = crntSoln.ComputeValue();
	//System.out.print("\nChecking solution ");
	//crntSoln.Print(" ");

	if (crntVal == DefineConstants.INVALID_VALUE)
	{
		return;
	}

	if (bestSoln.GetValue() == DefineConstants.INVALID_VALUE) //The first solution is initially the best solution
	{
		bestSoln.Copy(crntSoln);
	}
	else
	{
		if (crntVal > bestSoln.GetValue())
		{
			bestSoln.Copy(crntSoln);
		}
	}
}

	public boolean ub1(int untakenVal){
		if(sum - untakenVal <= bestSoln.GetValue())
			return true;
		
		return false;
	}
	public boolean ub2(int itemNum_){
		int itemNum = itemNum_;
		int remainingSum = 0;
		for(int i = itemNum; i < inst.GetItemCnt(); i++){
			if(inst.GetItemWeight(i) <= inst.GetCapacity() - crntSoln.GetWeight()){
				remainingSum += inst.GetItemValue(i);
			}
		}
		if(sum + remainingSum <= bestSoln.GetValue())
			return true;
		
		return false;
	}

	public boolean ub3(int itemNum_){
		int itemNum = itemNum_;
		int remainingSum = 0;
		int cap = inst.GetCapacity() - crntSoln.GetWeight();
		int amountOfNums = inst.GetItemCnt() - itemNum;

		int[] vals = new int[amountOfNums];
		int[] weights = new int[amountOfNums];
		for(int i = 0; i < amountOfNums; i++){
			vals[i] = inst.GetItemValue(itemNum + i + 1);
			weights[i] = inst.GetItemWeight(itemNum + i + 1);
		}

		Arrays.sort(weights);
		Arrays.sort(vals);

		remainingSum = fractionalKnap(weights, vals,cap,amountOfNums);
		if(sum + remainingSum <= bestSoln.GetValue())
			return true;
		
		return false;
	}
	public int fractionalKnap(int[] weights,int[] vals,int cap, int amountOfNums){
		int sum = 0;
		int load = 0;
		for(int i = 0; i < amountOfNums && load < cap; i++){
			if(weights[i] <= cap - load){
				sum += vals[i];
				load += weights[i];
			}
			else{
				sum += (vals[i] / (cap - load));
				load = cap;
			}
		}
		return sum;
	}
	public KnapsackBBSolver(UPPER_BOUND ub_)
	{
		ub = ub_;

	}
	public void close()
	{
		if(ub != null){
			ub = null;
			crntSoln = null;
		}
	}

	public void Solve(KnapsackInstance inst_, KnapsackSolution soln_)
	{
		inst = inst_;
		bestSoln = soln_;
		crntSoln = new KnapsackSolution(inst);
		int items = inst.GetItemCnt();
		sum = 0;
		for(int i = 0; i <= items; i++)
			sum += inst.GetItemValue(i);
		int untakenVal = 0;
		int load = 0;
		FindSolns(1, untakenVal, load);
	}
}