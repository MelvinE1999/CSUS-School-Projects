import java.util.*;

// Dynamic programming solver
public class KnapsackDPSolver implements java.io.Closeable
{
	private KnapsackInstance inst;
	private KnapsackSolution soln;
	private int n;
	private int cap;

	public void findSoln(){
		int val;
		int[][] table = new int[n + 1][cap + 1];
		
		for(int j = 0; j <= cap; j++)
			table[0][j] = 0;
		for(int i = 1; i <= n; i++){
			for(int j = 0; j <= cap;j++){
				if(inst.GetItemWeight(i) > j)
					table[i][j] = table[i - 1][j];
				else{
					val = inst.GetItemValue(i) + 
						table[i - 1][j - inst.GetItemWeight(i)];
					table[i][j] = max(val, table[i-1][j]);
				}
			}
		}
		decideItems(table);
	}

	public int max(int val1, int val2){
		if(val1 > val2){
			return val1;
		}
		return val2;
	}

	public void decideItems(int[][] table){
		int j = cap;
		for(int i = n; i > 0; i--){
			if(table[i][j] > table[i - 1][j]){
				soln.TakeItem(i);
				j = j - inst.GetItemWeight(i);
			}
		}
		soln.ComputeValue();
	}

	public KnapsackDPSolver()
	{

	}
	public void close()
	{
    
	}
	public void Solve(KnapsackInstance inst_, KnapsackSolution soln_)
	{
		inst = inst_;
		soln = soln_;
		n = inst.GetItemCnt();
		cap = inst.GetCapacity();
		findSoln();
	}
}