#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

struct page{
   int pageNumber;
   int referenceBit;
   int timeStamp;
};

void clock(struct page *pages, int pageCount, int frameCount, int pageRequests){
   bool alreadyInQueue = false;
   int avaliableFrames;
   int clock = 0;
   int i;
   int pageFaults = 0;
   int pointer = 0;
   bool replacedPage = false;
   int removedPageNumber;
   struct page Queue[frameCount];

   avaliableFrames = frameCount;
   while(clock < pageRequests){
      if(avaliableFrames != 0){
         for(i = 0; i <= clock; i++){    
            if(clock == i){
               Queue[i].pageNumber = pages[clock].pageNumber;
               Queue[i].timeStamp = clock;
               printf("Page %d was loaded into frame %d\n", pages[clock].pageNumber, i);
       	       Queue[i].referenceBit = 0;
               avaliableFrames--;
               pageFaults++;
            }
            else if(Queue[i].timeStamp == 0 && i != 0){
               Queue[i].pageNumber = pages[clock].pageNumber;
               Queue[i].timeStamp = clock;
       	       Queue[i].referenceBit = 0;
               printf("Page %d was loaded into frame %d\n", pages[clock].pageNumber, i);
               avaliableFrames--;
               pageFaults++;
               break;
            }
            else if(pages[clock].pageNumber == Queue[i].pageNumber){
               printf("Page %d is already in frame %d\n", pages[clock].pageNumber, i);
               Queue[i].referenceBit = 1;
               break;
            }
         }
      }
      else{
         for(i = 0; i < frameCount; i++){
            if(pages[clock].pageNumber == Queue[i].pageNumber){
               printf("Page %d is already in frame %d\n", pages[clock].pageNumber, i);
               alreadyInQueue = true;
               Queue[i].referenceBit = 1;
               Queue[i].timeStamp = clock;
               break;
            }
         }
         if(alreadyInQueue == false){
            while(replacedPage == false){
               if(Queue[pointer].referenceBit == 0){
                  removedPageNumber = Queue[pointer].pageNumber;
                  Queue[pointer].pageNumber = pages[clock].pageNumber;
                  Queue[pointer].timeStamp = clock;
                  printf("Page %d unloaded from Frame %d, Page %d loaded into Frame %d\n",
                       removedPageNumber, pointer, Queue[pointer].pageNumber, pointer);
                  pageFaults++;
                  replacedPage = true;
                  break;
               }
               else{
                  Queue[pointer].referenceBit = 0;
                  Queue[pointer].timeStamp = clock;
                  if(pointer == frameCount - 1)
                     pointer = 0;
                  else
                     pointer++;
               }
            }
            if(pointer == frameCount - 1)
               pointer = 0;
            else
               pointer++;
         }
      }
      alreadyInQueue = false;
      clock++;
      replacedPage = false;
   } 
   printf("Amount of page faults: %d\n", pageFaults);
}

void lru(struct page *pages, int pageCount, int frameCount, int pageRequests){
   bool alreadyInQueue = false;
   int avaliableFrames;
   int clock = 0;
   int i;
   int lruIndex;
   int lruTimeStamp;
   int removedPageNumber;
   int pageFaults = 0;
   struct page Queue[frameCount];
   

   avaliableFrames = frameCount;
   while(clock < pageRequests){
      if(avaliableFrames != 0){
         for(i = 0; i <= clock; i++){
            if(clock == i){
               Queue[i].pageNumber = pages[clock].pageNumber;
               Queue[i].timeStamp = clock;
               printf("Page %d was loaded into frame %d\n", pages[clock].pageNumber, i);
               avaliableFrames--;
               pageFaults++;
            }
            else if(Queue[i].timeStamp == 0 && i != 0){
               Queue[i].pageNumber = pages[clock].pageNumber;
               Queue[i].timeStamp = clock;
               printf("Page %d was loaded into frame %d\n", pages[clock].pageNumber, i);
               avaliableFrames--;
               pageFaults++;
               break;
            }
            else if(pages[clock].pageNumber == Queue[i].pageNumber){
               printf("Page %d is already in frame %d\n", pages[clock].pageNumber, i);
               break;
            }
         }
      }
      else{
         for(i = 0; i < frameCount; i++){
            if(pages[clock].pageNumber == Queue[i].pageNumber){
               printf("Page %d is already in frame %d\n", pages[clock].pageNumber, i);
               alreadyInQueue = true;
               Queue[i].timeStamp = clock;
               break;
            }	 
         }
         lruIndex = 0;
         lruTimeStamp = Queue[0].timeStamp;
         if(alreadyInQueue == false){
            for(i = 0; i < frameCount; i++){
               if(lruTimeStamp >  Queue[i].timeStamp){
                  lruTimeStamp = Queue[i].timeStamp;
                  lruIndex = i;
               }
            }
            removedPageNumber = Queue[lruIndex].pageNumber;
            Queue[lruIndex].pageNumber = pages[clock].pageNumber;
            Queue[lruIndex].timeStamp = clock;
            printf("Page %d unloaded from Frame %d, Page %d loaded into Frame %d\n", 
                   removedPageNumber, lruIndex, Queue[lruIndex].pageNumber, lruIndex);
            pageFaults++;
         } 
      }
      alreadyInQueue = false;
      clock++;
   }

   printf("Amount of page faults: %d\n", pageFaults);
}

int main(int argc, char *argv[]){
   int i;
   int frameCount;
   int pageCount;
   int pageRequests;
   int tempVar;

   if(argc == 0){
       printf("Usage: proj4 input_file [LRU|CLOCK]\n");
       return 0;
   }

   FILE *f = fopen(argv[1], "r");

   if(f == NULL){
       printf("Error. File not found.\n");
       return 0;
   }

   if(argc == 1){
       printf("Usage: proj4 input_file [LRU|CLOCK]\n");
       return 0;
   }
   
   fscanf(f, "%d", &pageCount);
   fscanf(f, "%d", &frameCount);
   fscanf(f, "%d", &pageRequests);

   struct page pages[pageRequests];

   for(i = 0; i < pageRequests; i++){
      fscanf(f, "%d", &tempVar);
      pages[i].pageNumber = tempVar;
   }
 
   fclose(f);

   if(strcmp(argv[2], "LRU") == 0){
      lru(pages, pageCount, frameCount, pageRequests);
   }
   else if(strcmp(argv[2], "CLOCK") == 0){
      clock(pages, pageCount, frameCount, pageRequests);
   }
   else{
       printf("Usage: proj4 input_file [LRU|CLOCK]\n");
       return 0;
   }

   return 0;
}
