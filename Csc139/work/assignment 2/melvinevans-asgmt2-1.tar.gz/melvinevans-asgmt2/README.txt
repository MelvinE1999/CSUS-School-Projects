To run any of these versions of the program first start with running the
 make file.

To run FCFS:
To run this version use the format of "./proj2 [text file] FCFS". 

To run RR:
Use the format of "./proj2 [text file] RR [time quantem]".

To run SRJF:
Use the format of "./proj2 [text file] SRJF"/

For all of these versions they will run through their respective algorithms
and then provide the cpu usage, average wait time, average response time, and 
average turnaround time.
