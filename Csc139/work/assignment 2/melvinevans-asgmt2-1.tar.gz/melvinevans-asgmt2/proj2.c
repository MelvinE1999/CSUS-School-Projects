#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct process{
   int arrival;
   int burst;
   bool finished;
   bool firstExecute;
   bool inQueue;
   int pid;
   bool swapped;
};


void srjf(struct process* processes, int processCount){
   int clock = 0;
   double cpuUsage;
   int downtime = 0;
   int finishedCount = 0;
   int i;
   int j;
   int minArrivalIndex;
   int minBurstTimeIndex;
   int processesInQueue = 0;
   struct process readyQueue[processCount + 1];
   double responseAvg = 0;
   double responseTime = 0;
   struct process tempProcess;
   double turnaroundAvg = 0;
   double turnaroundTime = 0;
   double waitingAvg = 0;
   double waitingTime = 0;

   for(i = 0; i < processCount - 1; i++){
      minArrivalIndex = i;
      for(j = i + 1; j < processCount; j++){
         if(processes[j].arrival < processes[minArrivalIndex].arrival){
            minArrivalIndex = j;
            tempProcess = processes[minArrivalIndex];
            processes[minArrivalIndex] = processes[i];
            processes[i] = tempProcess;
         }
      }
   }

   while(finishedCount != processCount){
      for(i = 0; i < processCount; i++){
         if(processes[i].inQueue){
            continue;
         }
         else if(processes[i].arrival > clock){
            break;
         }
         readyQueue[processesInQueue] = processes[i];
         processes[i].inQueue = true;
         processesInQueue++;
      }
      printf("<system time %5d> process ", clock);
      if(processesInQueue != 0){
         for(i = 0; i < processesInQueue - 1; i++){
           minBurstTimeIndex = i;
           for(j = i + 1; j < processesInQueue; j++){
               if(readyQueue[j].burst < readyQueue[minBurstTimeIndex].burst){
                  minBurstTimeIndex = j;
                  if(i == 0){
                     readyQueue[0].swapped = true;
                  }
                  tempProcess = readyQueue[minBurstTimeIndex];
                  readyQueue[minBurstTimeIndex] = readyQueue[i];
                  readyQueue[i] = tempProcess;
               }
           }
         }
         if(readyQueue[0].burst == 0){
            turnaroundTime = (double) clock - readyQueue[0].arrival;
            printf("%5d is finished....", readyQueue[0].pid);
            for(i = 0; i < processCount - 1; i++){
               tempProcess = readyQueue[i];
               readyQueue[i] = readyQueue[i + 1];
               readyQueue[i + 1] = tempProcess;
            }
            finishedCount++;
            clock--;
            processesInQueue--;
         }      
         else{
            printf("%5d is running", readyQueue[0].pid);
            readyQueue[0].burst = readyQueue[0].burst - 1;
            if(readyQueue[0].firstExecute == false){
               readyQueue[0].firstExecute = true;
               responseTime = (double) clock - readyQueue[0].arrival;
               waitingTime = (double) clock - readyQueue[0].arrival;
            }
            if(readyQueue[0].swapped){
               waitingTime = (double) clock - readyQueue[0].arrival;
               readyQueue[0].swapped = false;
            }
         }      
      }
      else{
         printf("none running");
         downtime++;
      }
      printf("\n");
      clock++;
      waitingAvg += waitingTime;
      responseAvg += responseTime;
      turnaroundAvg += turnaroundTime;
      waitingTime = 0;
      responseTime = 0;
      turnaroundTime = 0;
   }
   cpuUsage = (clock - downtime) / clock;
   cpuUsage *= 100;
   waitingAvg = waitingAvg / processCount;
   responseAvg = responseAvg / processCount;
   turnaroundAvg = turnaroundAvg / processCount;
   printf("<system time %5d> All processes finished....\n\n", clock);    
   printf("Cpu Usage               : %.2f%%\n", cpuUsage);
   printf("Average wait time       : %.2f\n", waitingAvg);
   printf("Average Response time   : %.2f\n", responseAvg);
   printf("Average turnaround time : %.2f\n", turnaroundAvg);
}


void rr(struct process* processes, int processCount, int quantem){
   int clock;
   double cpuUsage;
   double downtime = 0;
   int finishedCount = 0;
   int i;
   int j;
   int minArrivalIndex;
   int processesInQueue = 0;
   struct process readyQueue[processCount + 1];
   double responseAvg = 0;
   double responseTime = 0;
   struct process tempProcess;
   double turnaroundAvg = 0;
   double turnaroundTime = 0;
   int quantemClock = 0;
   double waitingAvg = 0;
   double waitingTime = 0;

   for(i = 0; i < processCount - 1; i++){
      minArrivalIndex = i;
      for(j = i + 1; j < processCount; j++){
         if(processes[j].arrival < processes[minArrivalIndex].arrival){
            minArrivalIndex = j;
            tempProcess = processes[minArrivalIndex];
            processes[minArrivalIndex] = processes[i];
            processes[i] = tempProcess;
         }
      }
   }

   while(finishedCount != processCount){
      if(quantemClock == quantem){
         for(j = 0; j < processesInQueue - 1; j++){
            tempProcess = readyQueue[j];
            readyQueue[j] = readyQueue[j + 1];
            readyQueue[j + 1] = tempProcess;
         }
         quantemClock = 0;
      }
      for(i = 0; i < processCount; i++){
         if(processes[i].inQueue){
            continue;
         }
         else if(processes[i].arrival > clock){
            continue;
         }
         readyQueue[processesInQueue] = processes[i];
         processes[i].inQueue = true;
         processesInQueue++;
      }
      printf("<system time %5d> process ", clock);
      if(processesInQueue != 0){
         if(readyQueue[0].burst == 0){
             turnaroundTime = (double) clock - readyQueue[0].arrival;
             printf("%5d is finished....", readyQueue[0].pid);
             for(i = 0; i < processCount - 1; i++){
                tempProcess = readyQueue[i];
                readyQueue[i] = readyQueue[i + 1];
                readyQueue[i + 1] = tempProcess;
             }
             finishedCount++;
             clock--;
             processesInQueue--;
             quantemClock = -1;
         }
         else{
            printf("%5d is running", readyQueue[0].pid);
            readyQueue[0].burst = readyQueue[0].burst - 1;
            if(readyQueue[0].firstExecute == false){
               readyQueue[0].firstExecute = true;
               responseTime = (double) clock - readyQueue[0].arrival;
            }
            if(quantemClock == 0){
               waitingTime = (double) clock - readyQueue[0].arrival;
            }
         }
      }
      else{
         printf("none running");
         downtime++;
      }
      printf("\n");
      clock++;
      quantemClock++;
      waitingAvg += waitingTime;
      responseAvg += responseTime;
      turnaroundAvg += turnaroundTime;
      waitingTime = 0;
      turnaroundTime = 0;
      responseTime = 0;
   }
   cpuUsage = (clock - downtime) / clock;
   cpuUsage *= 100;
   waitingAvg = waitingAvg / processCount;
   responseAvg = responseAvg / processCount;
   turnaroundAvg = turnaroundAvg / processCount;
   printf("<system time %5d> All Processes finished.....\n\n", clock);
   printf("Cpu Usage               : %.2f%%\n", cpuUsage);
   printf("Average wait time       : %.2f\n", waitingAvg);
   printf("Average Response Time   : %.2f\n", responseAvg);
   printf("Average TurnaroundTime  : %.2f\n", turnaroundAvg);
}


void fcfs(struct process* processes, int processCount){
   int clock = 0;
   double cpuUsage;
   int downtime = 0;
   int finishedCount = 0;
   int i;
   int j;
   int minArrivalIndex;
   int processesInQueue = 0;
   struct process readyQueue[processCount + 1];
   double responseAvg = 0;
   double responseTime = 0;
   struct process tempProcess;
   double turnaroundAvg = 0;
   double turnaroundTime = 0;
   double waitingAvg = 0;
   double waitingTime = 0;

   
   for(i = 0; i < (processCount - 1);i++){
      minArrivalIndex = i; 
      for(j = i + 1; j < processCount; j++){
         if(processes[j].arrival < processes[minArrivalIndex].arrival){
            minArrivalIndex = j;
            tempProcess = processes[minArrivalIndex];
            processes[minArrivalIndex] = processes[i];
            processes[i] = tempProcess; 
         }
      } 
   }
   while(finishedCount != processCount){
      for(i = 0; i < processCount; i++){
         if(processes[i].inQueue){
            continue;
         }
         else if(processes[i].arrival > clock){
            break;
         }
         readyQueue[processesInQueue] = processes[i];
         processes[i].inQueue = true;
         processesInQueue++;
      }
      printf("<system time %5d> process ", clock);
      if(processesInQueue != 0){
         if(readyQueue[0].burst == 0){
             turnaroundTime = (double) clock - readyQueue[0].arrival;             
             printf("%5d is finished....", readyQueue[0].pid);
             for(i = 0; i < processCount - 1; i++){
                tempProcess = readyQueue[i];
                readyQueue[i] = readyQueue[i + 1];
                readyQueue[i + 1] = tempProcess;
             }
             finishedCount++;
             clock--;
             processesInQueue--;
         }
         else{
            printf("%5d is running", readyQueue[0].pid); 
            readyQueue[0].burst = readyQueue[0].burst - 1;
            if(readyQueue[0].firstExecute == false){
               readyQueue[0].firstExecute = true;
               responseTime = (double) clock - readyQueue[0].arrival;
               waitingTime = (double) clock - readyQueue[0].arrival;
            }
         }
      }
      else{
         printf("none running");
         downtime++;
      }
      printf("\n");
      clock++;  
      waitingAvg += waitingTime;
      responseAvg += responseTime;
      turnaroundAvg += turnaroundTime;
      waitingTime = 0;
      responseTime = 0;
      turnaroundTime = 0;
   }
   cpuUsage = (clock - downtime) / clock;
   cpuUsage = cpuUsage * 100;
   waitingAvg = waitingAvg / processCount;
   responseAvg = responseAvg / processCount;
   turnaroundAvg = turnaroundAvg / processCount;
   printf("<system time %5d> All Processes finished.......\n\n", clock);
   printf("Cpu Usage               : %.2f%%\n", cpuUsage);
   printf("Average Wait Time       : %.2f\n", waitingAvg);
   printf("Average Response Time   : %.2f\n", responseAvg);
   printf("Average Turnaround TIme : %.2f\n", turnaroundAvg);
}


int main(int argc, char *argv[]){
   int i;
   int item = 1;
   int numHolder;
   int processCount = 0;
   struct process processes[100];
   int processesMaxAmount = 10;
   int quantem;


   if(argc == 0){
       printf("Usage: proj2 input_file FCFS|RR|SRJF [quantum]");
   }

   FILE *f = fopen(argv[1],"r");

   if(f == NULL){
       printf("Error. File not found.");
       exit(0);
   }

   while(fscanf(f, "%d", &numHolder) > 0) {
      if(item == 1){
         processes[processCount].pid = numHolder;
         item++;
      }
      else if(item == 2){
         processes[processCount].arrival = numHolder;
         item++;
      }
      else{
         processes[processCount].burst = numHolder;
         processes[processCount].firstExecute = false;
         processes[processCount].finished = false;
         processes[processCount].inQueue = false;
         processes[processCount].swapped = false;
         item = 1;
         processCount++;
      }
   }
         
   if(strcmp(argv[2],"FCFS") == 0){
       fcfs(processes, processCount);
   }
   else if(strcmp(argv[2],"RR") == 0){
       quantem = atoi(argv[3]);
       rr(processes, processCount, quantem);
   }
   else if(strcmp(argv[2], "SRJF") == 0){
      srjf(processes, processCount);
   }
   else{
       printf("Usage: proj2 input_file FCFS|RR|SRJF [quantum]");      
   }
   
   return 0;
}
