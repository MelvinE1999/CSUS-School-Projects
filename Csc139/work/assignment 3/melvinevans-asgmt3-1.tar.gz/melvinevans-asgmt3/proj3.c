#include "buffer.h"
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

buffer_item buffer[BUFFER_SIZE];
sem_t empty;
sem_t full;
int front;
int itemsConsumed;
int itemsToProduce;
unsigned int max;
pthread_mutex_t mutex;
int rear;
unsigned int sleep;
sem_t wait;


int insert_item(buffer_item item) {
   /* insert item into buffer
   return 0 if successful, otherwise
   return -1 indicating an error condition */

   if(rear == BUFFER_SIZE - 1){
      if(front == 0)
         return -1; // queue is full
      else{
         rear = 0;
         buffer[rear] = item;
      }
   }
   else if(rear == -1){
      front = 0;
      rear = 0;
      buffer[rear] = item;
   }
   else{
      rear += 1;
      buffer[rear] = item;
   }

   itemsToProduce -= 1;

   return 0;
}

int remove_item(buffer_item *item) {
   /* remove an object from buffer placing it in item
   return 0 if successful, otherwise
   return -1 indicating an error condition */

   if(rear == -1)
      return -1;
   else{
      *item = buffer[front];
      if(front == rear){
         front = -1;
         rear = -1;
      }
      else if(front == BUFFER_SIZE -1)
         front = 0;
      else
         front++;
   }

   itemsConsumed -= 1;

   return 0;
}

void *producer(void *param) {
   buffer_item item;
   int id = *(int*)param;
   max = RAND_MAX % 10000;
   sleep = rand_r(&max);
   while (true) {

      /* sleep for a random amount of milliseconds */
      usleep(&sleep);

      sem_wait(&empty);

      if(itemsToProduce <= 0)
         break;

      pthread_mutex_lock(&mutex);

      /* generate a random number */
      item = rand_r(&max);
      if (insert_item(item))
         printf("report error condition");
      else
         printf("producer %d produced %d\n", id, item);

      pthread_mutex_unlock(&mutex);
      sem_post(&full);

      if(itemsToProduce <= 0)
         break;
   }
   pthread_exit(0);
}

void *consumer(void *param) {
   buffer_item item;
   int id = *(int*)param;
   max = RAND_MAX % 10000;
   sleep = rand_r(&max);
   while (true) {
         
      /* sleep for a random amount of milliseconds */
      usleep(&sleep);

      sem_wait(&full);

      pthread_mutex_lock(&mutex);

      if(itemsConsumed == 0){
         sem_post(&wait);
         break;
      } 

      if (remove_item(&item))
         printf("report error condition");
      else
         printf("consumer %d consumed %d\n", (id+1), item);

      pthread_mutex_unlock(&mutex);
      sem_post(&empty);

      if(itemsConsumed == 0){
         sem_post(&wait);
         break;
      }
   }
   pthread_exit(0);
}

void initiateBuffer(){
   front = -1;
   rear = -1;
   pthread_mutex_init(&mutex, NULL);
   sem_init(&empty, 0, BUFFER_SIZE);
   sem_init(&full, 0, 0);
   sem_init(&wait, 0, 0);
}

int main(int argc, char *argv[]){
   int i;
   int j;
   int numOfConsumers;
   int numOfProducers;
   pthread_attr_t attr;

   /* 1. Get command line arguments argv[1],argv[2],argv[3] */
   if(argc != 4){
      printf("Usage: ./proj3 [#producer threads] [#consumer threads] [#item produced]\n");
      return 0;
   }
   else{
      numOfProducers = atoi(argv[1]);
      numOfConsumers = atoi(argv[2]);
      itemsToProduce = atoi(argv[3]);
      itemsConsumed = atoi(argv[3]);
   }
   pthread_t producers[numOfProducers + 1];
   pthread_t consumers[numOfConsumers + 1];

   if(numOfProducers == 0 || numOfConsumers == 0){
     printf("0 Producers or consumers provided.\n");
     return;
   }


   /* 2. Initialize buffer */
   initiateBuffer();

   /* 3. Create producer thread(s) */
   for(i = 0; i < numOfProducers; i++)
      pthread_create(&producers[i], &attr, producer,(void*) (&i));

   /* 4. Create consumer thread(s) */
   for(j = 0; j < numOfConsumers; j++)
      pthread_create(&consumers[j], &attr, consumer,(void*) (&j));

   /* 5. Wait until the specified number of items are produced and consumed */
   sem_wait(&wait);

   /* 6. Exit */
   return 0;
}
