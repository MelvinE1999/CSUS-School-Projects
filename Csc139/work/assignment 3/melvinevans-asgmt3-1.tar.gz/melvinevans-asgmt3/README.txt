In order to run this program first call make to create the object. Then
type in "./proj3 [#producer threads] [#consumer threads] [#item produced]"
in order to get the output. Please provide more than 0 producer an 
consumer threads for you to be able to actually run the program. If not
you will be met with a message telling you to meet this certain 
requirement.
